/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase_6;

/**
 *
 * @author Victoria
 */
public class Cuadrado {
    
    private int lado;
    
    public void agregar_lado (int l){
        lado = l;
    
    }
    
    public int obtener_lado () {
        return lado;
    }
    
    public int calcular_area () {
        // int area = lado * lado;
        int area1 = obtener_lado () * obtener_lado ();
        return area1;
    }
    
    public int calcular_perimetro () {
        int perimetro = obtener_lado ()+ obtener_lado ()+ obtener_lado () + obtener_lado ();
        return perimetro;
        
        
    }

}


   